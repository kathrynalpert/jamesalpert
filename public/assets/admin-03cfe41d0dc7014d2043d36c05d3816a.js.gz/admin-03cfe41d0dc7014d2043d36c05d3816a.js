// Use this to customize the wymeditor boot process
// Just mirror the options specified in boot_wym.js with the new options here.
// This will completely override anything specified in boot_wym.js for that key.
// e.g. skin: 'something_else'
typeof custom_wymeditor_boot_options=="undefined"&&(custom_wymeditor_boot_options={});